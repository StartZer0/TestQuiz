import { pgTable, text, serial, integer, boolean, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

// Form schema
export const forms = pgTable("forms", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  createdAt: text("created_at").notNull(),
  questions: jsonb("questions").notNull(),
  userId: integer("user_id").references(() => users.id),
});

export const insertFormSchema = createInsertSchema(forms).pick({
  title: true,
  createdAt: true,
  questions: true,
  userId: true,
});

export type InsertForm = z.infer<typeof insertFormSchema>;
export type Form = typeof forms.$inferSelect;

// Option schema for frontend use
export const optionSchema = z.object({
  id: z.string(),
  text: z.string(),
  imageUrl: z.string().optional(),
  isCorrect: z.boolean().default(false),
});

export type Option = z.infer<typeof optionSchema>;

// Explanatory Item schema for complex questions
export const explanatoryItemSchema = z.object({
  number: z.string(),
  text: z.string(),
});

export type ExplanatoryItem = z.infer<typeof explanatoryItemSchema>;

// Question schema for frontend use
export const questionSchema = z.object({
  id: z.string(),
  type: z.enum([
    "multiple-choice", 
    "short-answer", 
    "paragraph", 
    "checkbox", 
    "dropdown"
  ]),
  text: z.string(),
  imageUrl: z.string().optional(),
  options: z.array(optionSchema).optional(),
  required: z.boolean().default(true),
  points: z.number().default(1),
  correctAnswer: z.string().optional(),
  explanatoryItems: z.array(explanatoryItemSchema).optional(), // For complex questions with explanatory items
});

export type Question = z.infer<typeof questionSchema>;

// FormData schema for frontend use
export const formDataSchema = z.object({
  title: z.string(),
  questions: z.array(questionSchema),
});

export type FormData = z.infer<typeof formDataSchema>;

// Upload document schema
export const uploadDocumentSchema = z.object({
  fileName: z.string(),
  userId: z.number().optional(),
});

export type UploadDocument = z.infer<typeof uploadDocumentSchema>;

// Parser result schema
export const parserResultSchema = z.object({
  title: z.string().optional(),
  questions: z.array(questionSchema),
  extractedImages: z.array(z.string()).optional(),
  potentialMerges: z.array(z.object({
    sourceIndex: z.number(),
    targetIndex: z.number(),
    reason: z.string(),
  })).optional(),
});

export type ParserResult = z.infer<typeof parserResultSchema>;
