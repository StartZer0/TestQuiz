import React, { createContext, useContext, useState } from "react";
import { nanoid } from "nanoid";
import { FormData, Question, Option, ParserResult, questionSchema } from "@shared/schema";
import { DocumentFile, FormBuilderContextType } from "@/types";

// Initial form data
const initialFormData: FormData = {
  title: "",
  questions: [],
};

// Create context
const FormBuilderContext = createContext<FormBuilderContextType | undefined>(undefined);

// Provider component
export const FormBuilderProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [formData, setFormData] = useState<FormData>(initialFormData);
  const [uploadedFile, setUploadedFile] = useState<DocumentFile | null>(null);
  const [parsedResult, setParsedResult] = useState<ParserResult | null>(null);
  const [processing, setProcessing] = useState<boolean>(false);
  const [currentStep, setCurrentStep] = useState<number>(1);

  // Form methods
  const setFormTitle = (title: string) => {
    setFormData({ ...formData, title });
  };

  const addQuestion = (question: Question) => {
    // Ensure question has an ID
    const questionWithId = {
      ...question,
      id: question.id || nanoid(),
    };

    setFormData({
      ...formData,
      questions: [...formData.questions, questionWithId],
    });
  };

  const updateQuestion = (index: number, question: Question) => {
    const updatedQuestions = [...formData.questions];
    updatedQuestions[index] = question;
    setFormData({ ...formData, questions: updatedQuestions });
  };

  const removeQuestion = (index: number) => {
    const updatedQuestions = [...formData.questions];
    updatedQuestions.splice(index, 1);
    setFormData({ ...formData, questions: updatedQuestions });
  };

  const reorderQuestions = (startIndex: number, endIndex: number) => {
    const result = Array.from(formData.questions);
    const [removed] = result.splice(startIndex, 1);
    result.splice(endIndex, 0, removed);
    setFormData({ ...formData, questions: result });
  };

  // Question field updates
  const updateQuestionType = (index: number, type: Question['type']) => {
    const updatedQuestions = [...formData.questions];
    updatedQuestions[index] = { ...updatedQuestions[index], type };
    setFormData({ ...formData, questions: updatedQuestions });
  };

  const updateQuestionText = (index: number, text: string) => {
    const updatedQuestions = [...formData.questions];
    updatedQuestions[index] = { ...updatedQuestions[index], text };
    setFormData({ ...formData, questions: updatedQuestions });
  };

  const updateQuestionImage = (index: number, imageUrl: string) => {
    const updatedQuestions = [...formData.questions];
    updatedQuestions[index] = { ...updatedQuestions[index], imageUrl };
    setFormData({ ...formData, questions: updatedQuestions });
  };

  const updateQuestionRequired = (index: number, required: boolean) => {
    const updatedQuestions = [...formData.questions];
    updatedQuestions[index] = { ...updatedQuestions[index], required };
    setFormData({ ...formData, questions: updatedQuestions });
  };

  const updateQuestionPoints = (index: number, points: number) => {
    const updatedQuestions = [...formData.questions];
    updatedQuestions[index] = { ...updatedQuestions[index], points };
    setFormData({ ...formData, questions: updatedQuestions });
  };

  const updateQuestionCorrectAnswer = (index: number, answer: string) => {
    const updatedQuestions = [...formData.questions];
    updatedQuestions[index] = { ...updatedQuestions[index], correctAnswer: answer };
    setFormData({ ...formData, questions: updatedQuestions });
  };

  // Option methods
  const addOption = (questionIndex: number, option: Option) => {
    const updatedQuestions = [...formData.questions];
    const question = updatedQuestions[questionIndex];
    const options = question.options || [];

    const optionWithId = {
      ...option,
      id: option.id || nanoid(),
    };

    updatedQuestions[questionIndex] = {
      ...question,
      options: [...options, optionWithId],
    };

    setFormData({ ...formData, questions: updatedQuestions });
  };

  const updateOption = (questionIndex: number, optionIndex: number, option: Option) => {
    const updatedQuestions = [...formData.questions];
    const question = updatedQuestions[questionIndex];
    const options = [...(question.options || [])];
    options[optionIndex] = option;

    updatedQuestions[questionIndex] = {
      ...question,
      options,
    };

    setFormData({ ...formData, questions: updatedQuestions });
  };

  const removeOption = (questionIndex: number, optionIndex: number) => {
    const updatedQuestions = [...formData.questions];
    const question = updatedQuestions[questionIndex];
    const options = [...(question.options || [])];
    options.splice(optionIndex, 1);

    updatedQuestions[questionIndex] = {
      ...question,
      options,
    };

    setFormData({ ...formData, questions: updatedQuestions });
  };

  const setCorrectOption = (questionIndex: number, optionIndex: number) => {
    const updatedQuestions = [...formData.questions];
    const question = updatedQuestions[questionIndex];
    const options = (question.options || []).map((opt, idx) => ({
      ...opt,
      isCorrect: idx === optionIndex,
    }));

    updatedQuestions[questionIndex] = {
      ...question,
      options,
    };

    setFormData({ ...formData, questions: updatedQuestions });
  };

  // Navigation
  const goToNextStep = () => {
    setCurrentStep((prev) => Math.min(prev + 1, 4));
  };

  const goToPreviousStep = () => {
    setCurrentStep((prev) => Math.max(prev - 1, 1));
  };

  // Merge items
  const mergeItems = (indices: number[]) => {
    if (indices.length < 2) return;

    const updatedQuestions = [...formData.questions];
    const baseIndex = Math.min(...indices);
    const baseQuestion = { ...updatedQuestions[baseIndex] };
    
    // Sort indices in descending order to avoid shifting issues when removing
    const sortedIndices = [...indices].sort((a, b) => b - a);
    
    // Skip the base question and collect data from other questions to merge
    for (let i = 0; i < sortedIndices.length; i++) {
      const idx = sortedIndices[i];
      if (idx === baseIndex) continue; // Skip base question
      
      const question = updatedQuestions[idx];
      
      // Merge text (append with a space)
      if (question.text && question.text.trim()) {
        baseQuestion.text = `${baseQuestion.text} ${question.text}`.trim();
      }
      
      // Merge images (prefer the base image, but use the other if base doesn't have one)
      if (!baseQuestion.imageUrl && question.imageUrl) {
        baseQuestion.imageUrl = question.imageUrl;
      }
      
      // Merge options
      if (question.options && question.options.length > 0) {
        baseQuestion.options = [
          ...(baseQuestion.options || []),
          ...question.options,
        ];
      }
      
      // Remove the merged question
      updatedQuestions.splice(idx, 1);
    }
    
    // Update the base question with merged data
    updatedQuestions[baseIndex] = baseQuestion;
    
    setFormData({ ...formData, questions: updatedQuestions });
  };

  const contextValue: FormBuilderContextType = {
    formData,
    uploadedFile,
    parsedResult,
    processing,
    currentStep,
    
    // Document upload actions
    setUploadedFile,
    
    // Processing actions
    setParsedResult,
    setProcessing,
    
    // Form data actions
    setFormData,
    setFormTitle,
    addQuestion,
    updateQuestion,
    removeQuestion,
    reorderQuestions,
    
    // Question actions
    updateQuestionType,
    updateQuestionText,
    updateQuestionImage,
    updateQuestionRequired,
    updateQuestionPoints,
    updateQuestionCorrectAnswer,
    
    // Options actions
    addOption,
    updateOption,
    removeOption,
    setCorrectOption,
    
    // Navigation
    goToNextStep,
    goToPreviousStep,
    setCurrentStep,
    
    // Merge items
    mergeItems,
  };

  return React.createElement(
    FormBuilderContext.Provider,
    { value: contextValue },
    children
  );
};

// Custom hook to use the context
export const useFormBuilder = (): FormBuilderContextType => {
  const context = useContext(FormBuilderContext);
  if (context === undefined) {
    throw new Error("useFormBuilder must be used within a FormBuilderProvider");
  }
  return context;
};
