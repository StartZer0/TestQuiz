import React, { useState } from "react";
import { useLocation } from "wouter";
import { useFormBuilder } from "@/hooks/useFormBuilder";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { ArrowLeft, ArrowRight, Eye } from "lucide-react";
import { DragDropContext, DropResult } from 'react-beautiful-dnd';
import QuestionList from "@/components/QuestionList";
import MergeModal from "@/components/MergeModal";
import { nanoid } from "nanoid";

const Edit: React.FC = () => {
  const [, navigate] = useLocation();
  const { 
    formData, 
    setFormTitle, 
    addQuestion,
    reorderQuestions,
    goToNextStep,
    goToPreviousStep,
    parsedResult
  } = useFormBuilder();

  const [isMergeModalOpen, setIsMergeModalOpen] = useState(false);
  const [selectedIndices, setSelectedIndices] = useState<number[]>([]);

  // Redirect if no processed data
  React.useEffect(() => {
    if (!parsedResult) {
      navigate('/upload');
    }
  }, [parsedResult]);

  const handleDragEnd = (result: DropResult) => {
    if (!result.destination) return;

    const { source, destination } = result;
    reorderQuestions(source.index, destination.index);
  };

  const handleAddQuestion = () => {
    addQuestion({
      id: nanoid(),
      type: "multiple-choice",
      text: "",
      required: true,
      points: 1,
      options: [
        { id: nanoid(), text: "", isCorrect: false },
        { id: nanoid(), text: "", isCorrect: false }
      ]
    });
  };

  const handleOpenMergeModal = (indices: number[]) => {
    setSelectedIndices(indices);
    setIsMergeModalOpen(true);
  };

  const handleBackClick = () => {
    goToPreviousStep();
    navigate('/process');
  };

  const handleContinueClick = () => {
    goToNextStep();
    navigate('/export');
  };

  return (
    <div>
      <Card className="bg-white shadow rounded-lg">
        <div className="p-6 border-b">
          <div className="flex justify-between items-center">
            <h2 className="text-xl font-semibold text-gray-900">Edit Extracted Form</h2>
            <div>
              <Button variant="outline" className="flex items-center">
                <Eye className="h-4 w-4 mr-2" />
                Preview
              </Button>
            </div>
          </div>
          <p className="text-gray-600 mt-2">
            Review and edit the extracted content before exporting your form.
          </p>
          
          {/* Form Title Section */}
          <div className="mt-6">
            <Label htmlFor="form-title" className="block text-sm font-medium text-gray-700">
              Form Title
            </Label>
            <Input
              id="form-title"
              value={formData.title}
              onChange={(e) => setFormTitle(e.target.value)}
              className="mt-1 block w-full"
              placeholder="Enter form title"
            />
          </div>
        </div>
        
        {/* Question List */}
        <DragDropContext onDragEnd={handleDragEnd}>
          <QuestionList onMergeItems={handleOpenMergeModal} onAddQuestion={handleAddQuestion} />
        </DragDropContext>
      </Card>
      
      {/* Bottom Action Bar */}
      <div className="mt-6 flex justify-between">
        <Button
          variant="outline"
          onClick={handleBackClick}
          className="flex items-center"
        >
          <ArrowLeft className="mr-2 h-4 w-4" />
          Back to Processing
        </Button>
        
        <Button
          onClick={handleContinueClick}
          className="flex items-center"
          disabled={formData.questions.length === 0}
        >
          Continue to Export
          <ArrowRight className="ml-2 h-4 w-4" />
        </Button>
      </div>
      
      {/* Merge Modal */}
      <MergeModal
        isOpen={isMergeModalOpen}
        onClose={() => setIsMergeModalOpen(false)}
        selectedIndices={selectedIndices}
        questions={formData.questions}
      />
    </div>
  );
};

export default Edit;
