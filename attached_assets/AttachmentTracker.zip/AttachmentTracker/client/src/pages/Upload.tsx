import React, { useState } from 'react';
import { useLocation } from 'wouter';
import { useFormBuilder } from '@/hooks/useFormBuilder';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { AlertCircle, File, Upload, ArrowRight } from 'lucide-react';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { DocumentFile } from '@/types';

const UploadPage: React.FC = () => {
  const [, navigate] = useLocation();
  const { 
    uploadedFile, 
    setUploadedFile, 
    goToNextStep 
  } = useFormBuilder();
  
  const [error, setError] = useState<string | null>(null);
  const [dragActive, setDragActive] = useState<boolean>(false);
  
  // Handle drag events
  const handleDrag = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === 'dragenter' || e.type === 'dragover') {
      setDragActive(true);
    } else if (e.type === 'dragleave') {
      setDragActive(false);
    }
  };
  
  // Handle drop event
  const handleDrop = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      handleFile(e.dataTransfer.files[0]);
    }
  };
  
  // Handle file input change
  const handleFileInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      handleFile(e.target.files[0]);
    }
  };
  
  // Process the file
  const handleFile = (file: File) => {
    setError(null);
    
    // Check file type
    if (!file.name.endsWith('.docx')) {
      setError('Only .docx files are currently supported.');
      return;
    }
    
    // Check file size (max 10MB)
    if (file.size > 10 * 1024 * 1024) {
      setError('File size exceeds the 10MB limit.');
      return;
    }
    
    // Set the uploaded file
    const documentFile: DocumentFile = {
      name: file.name,
      size: file.size,
      type: file.type,
      file: file
    };
    
    setUploadedFile(documentFile);
  };
  
  const handleContinue = () => {
    if (uploadedFile) {
      goToNextStep();
      navigate('/process');
    }
  };
  
  const clearFile = () => {
    setUploadedFile(null);
  };
  
  return (
    <div className="max-w-3xl mx-auto">
      <Card className="bg-white shadow rounded-lg">
        <CardHeader>
          <CardTitle className="text-xl font-semibold text-gray-900">Upload Document</CardTitle>
          <CardDescription>
            Upload a Word document (.docx) to extract questions, answers, and images.
          </CardDescription>
        </CardHeader>
        
        <CardContent>
          {error && (
            <Alert variant="destructive" className="mb-4">
              <AlertCircle className="h-4 w-4" />
              <AlertTitle>Error</AlertTitle>
              <AlertDescription>{error}</AlertDescription>
            </Alert>
          )}
          
          {!uploadedFile ? (
            <div 
              className={`border-2 border-dashed rounded-lg p-8 text-center ${
                dragActive ? 'border-primary bg-primary/5' : 'border-gray-300'
              }`}
              onDragEnter={handleDrag}
              onDragOver={handleDrag}
              onDragLeave={handleDrag}
              onDrop={handleDrop}
            >
              <Upload className="h-10 w-10 text-gray-400 mx-auto mb-4" />
              <h3 className="text-lg font-medium text-gray-900 mb-1">Drag and drop your file here</h3>
              <p className="text-gray-500 mb-4">Or click to browse files</p>
              
              <input 
                type="file" 
                id="file-upload" 
                className="hidden" 
                accept=".docx" 
                onChange={handleFileInputChange}
              />
              <Button 
                variant="outline" 
                onClick={() => document.getElementById('file-upload')?.click()}
              >
                Browse Files
              </Button>
              
              <p className="text-xs text-gray-400 mt-4">
                Supported format: .docx (Microsoft Word) • Maximum size: 10MB
              </p>
            </div>
          ) : (
            <div className="bg-gray-50 rounded-lg p-4 border border-gray-200">
              <div className="flex items-center">
                <div className="bg-primary/10 p-2 rounded-md mr-3">
                  <File className="h-6 w-6 text-primary" />
                </div>
                <div className="flex-1 min-w-0">
                  <h4 className="text-sm font-medium text-gray-900 truncate">{uploadedFile.name}</h4>
                  <p className="text-xs text-gray-500">
                    {(uploadedFile.size / 1024).toFixed(1)} KB • {uploadedFile.type}
                  </p>
                </div>
                <Button 
                  variant="ghost" 
                  size="sm" 
                  onClick={clearFile}
                  className="text-gray-500"
                >
                  Remove
                </Button>
              </div>
            </div>
          )}
        </CardContent>
      </Card>
      
      <div className="mt-6 flex justify-end">
        <Button 
          onClick={handleContinue}
          disabled={!uploadedFile}
          className="flex items-center"
        >
          Continue to Processing
          <ArrowRight className="ml-2 h-4 w-4" />
        </Button>
      </div>
    </div>
  );
};

export default UploadPage;
