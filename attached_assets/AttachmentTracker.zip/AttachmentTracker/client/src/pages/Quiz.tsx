import React, { useState } from 'react';
import { useFormBuilder } from '@/hooks/useFormBuilder';
import Layout from '@/components/Layout';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Label } from '@/components/ui/label';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { Progress } from '@/components/ui/progress';
import { CheckCircle, AlertCircle, ArrowRight } from 'lucide-react';

interface QuizResult {
  totalQuestions: number;
  correctAnswers: number;
  incorrectAnswers: number;
  score: number;
}

export default function Quiz() {
  const { formData } = useFormBuilder();
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [selectedAnswerId, setSelectedAnswerId] = useState<string | null>(null);
  const [isAnswerSubmitted, setIsAnswerSubmitted] = useState(false);
  const [isCorrect, setIsCorrect] = useState(false);
  const [quizResults, setQuizResults] = useState<QuizResult | null>(null);
  const [answeredQuestions, setAnsweredQuestions] = useState<Record<string, string>>({});

  const currentQuestion = formData.questions[currentQuestionIndex];
  const isLastQuestion = currentQuestionIndex === formData.questions.length - 1;
  const progressPercentage = (Object.keys(answeredQuestions).length / formData.questions.length) * 100;

  const handleAnswerSelection = (optionId: string) => {
    if (!isAnswerSubmitted) {
      setSelectedAnswerId(optionId);
    }
  };

  const handleAnswerSubmit = () => {
    if (!selectedAnswerId || isAnswerSubmitted) return;

    // Find the selected option
    const selectedOption = currentQuestion.options?.find(opt => opt.id === selectedAnswerId);
    
    // Check if the answer is correct
    const isCorrectAnswer = selectedOption?.isCorrect || false;
    setIsCorrect(isCorrectAnswer);
    
    // Mark this question as answered
    setAnsweredQuestions(prev => ({
      ...prev,
      [currentQuestion.id]: selectedAnswerId
    }));
    
    setIsAnswerSubmitted(true);
  };

  const handleNextQuestion = () => {
    if (isLastQuestion) {
      // Calculate final results
      let correctCount = 0;
      
      // Count correct answers
      Object.entries(answeredQuestions).forEach(([questionId, answerId]) => {
        const question = formData.questions.find(q => q.id === questionId);
        const option = question?.options?.find(opt => opt.id === answerId);
        if (option?.isCorrect) {
          correctCount++;
        }
      });
      
      const totalQuestions = formData.questions.length;
      const incorrectCount = totalQuestions - correctCount;
      const scorePercentage = Math.round((correctCount / totalQuestions) * 100);
      
      setQuizResults({
        totalQuestions,
        correctAnswers: correctCount,
        incorrectAnswers: incorrectCount,
        score: scorePercentage
      });
    } else {
      // Move to next question
      setCurrentQuestionIndex(prevIndex => prevIndex + 1);
      setSelectedAnswerId(null);
      setIsAnswerSubmitted(false);
    }
  };

  const restartQuiz = () => {
    setCurrentQuestionIndex(0);
    setSelectedAnswerId(null);
    setIsAnswerSubmitted(false);
    setAnsweredQuestions({});
    setQuizResults(null);
  };

  // If we have no questions, show a message
  if (formData.questions.length === 0) {
    return (
      <Layout>
        <div className="container mx-auto py-6">
          <Alert>
            <AlertCircle className="h-4 w-4" />
            <AlertTitle>No Questions Available</AlertTitle>
            <AlertDescription>
              Please upload and process a document first to create a quiz.
            </AlertDescription>
          </Alert>
        </div>
      </Layout>
    );
  }

  // If we've completed the quiz, show results
  if (quizResults) {
    return (
      <Layout>
        <div className="container mx-auto py-6">
          <Card className="w-full max-w-3xl mx-auto">
            <CardHeader>
              <CardTitle className="text-2xl font-bold text-center">Quiz Results</CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="text-center mb-6">
                <div className="text-4xl font-bold">{quizResults.score}%</div>
                <p className="text-muted-foreground">Your Score</p>
              </div>
              
              <div className="grid grid-cols-3 gap-4 text-center mb-6">
                <div className="p-4 bg-muted rounded-lg">
                  <div className="text-2xl font-bold">{quizResults.totalQuestions}</div>
                  <p className="text-sm text-muted-foreground">Total Questions</p>
                </div>
                <div className="p-4 bg-green-100 dark:bg-green-900 rounded-lg">
                  <div className="text-2xl font-bold text-green-600 dark:text-green-300">{quizResults.correctAnswers}</div>
                  <p className="text-sm text-muted-foreground">Correct</p>
                </div>
                <div className="p-4 bg-red-100 dark:bg-red-900 rounded-lg">
                  <div className="text-2xl font-bold text-red-600 dark:text-red-300">{quizResults.incorrectAnswers}</div>
                  <p className="text-sm text-muted-foreground">Incorrect</p>
                </div>
              </div>
              
              <Alert className={quizResults.score >= 70 ? "bg-green-100 dark:bg-green-900" : "bg-amber-100 dark:bg-amber-900"}>
                {quizResults.score >= 70 ? (
                  <CheckCircle className="h-4 w-4 text-green-600 dark:text-green-300" />
                ) : (
                  <AlertCircle className="h-4 w-4 text-amber-600 dark:text-amber-300" />
                )}
                <AlertTitle>
                  {quizResults.score >= 70 ? "Great job!" : "Keep practicing!"}
                </AlertTitle>
                <AlertDescription>
                  {quizResults.score >= 70 
                    ? "You've done well on this quiz. You have a good understanding of the material."
                    : "You might need some more review. Try taking the quiz again after studying the material."}
                </AlertDescription>
              </Alert>
            </CardContent>
            <CardFooter>
              <Button onClick={restartQuiz} className="w-full">
                Retake Quiz
              </Button>
            </CardFooter>
          </Card>
        </div>
      </Layout>
    );
  }

  // Render the current question
  return (
    <Layout>
      <div className="container mx-auto py-6">
        <Card className="w-full max-w-3xl mx-auto">
          <CardHeader>
            <div className="flex justify-between items-center mb-4">
              <div className="text-sm text-muted-foreground">
                Question {currentQuestionIndex + 1} of {formData.questions.length}
              </div>
              <div className="text-sm font-medium">
                Progress: {Math.round(progressPercentage)}%
              </div>
            </div>
            <Progress value={progressPercentage} className="h-2" />
            <CardTitle className="mt-4 text-xl font-semibold">
              {currentQuestion.text}
            </CardTitle>
          </CardHeader>
          
          <CardContent>
            {currentQuestion.imageUrl && (
              <div className="mb-4">
                <img 
                  src={currentQuestion.imageUrl} 
                  alt="Question Image" 
                  className="mx-auto rounded-md max-h-64 object-contain mb-4"
                />
              </div>
            )}

            {/* Display explanatory items if available */}
            {currentQuestion.explanatoryItems && currentQuestion.explanatoryItems.length > 0 && (
              <div className="mb-4 p-4 bg-muted rounded-lg">
                <h3 className="font-medium mb-2">Reference Information:</h3>
                <ul className="list-inside space-y-1">
                  {currentQuestion.explanatoryItems.map((item, idx) => (
                    <li key={idx}>
                      <span className="font-medium">{item.number}</span> {item.text}
                    </li>
                  ))}
                </ul>
              </div>
            )}
            
            <RadioGroup value={selectedAnswerId || ""} className="space-y-3">
              {currentQuestion.options?.map((option) => {
                // Determine the styling based on whether the answer is submitted and correct
                let optionClassName = "border border-input p-4 rounded-md";
                
                if (isAnswerSubmitted && option.id === selectedAnswerId) {
                  optionClassName += option.isCorrect 
                    ? " bg-green-100 border-green-500 dark:bg-green-900 dark:border-green-400" 
                    : " bg-red-100 border-red-500 dark:bg-red-900 dark:border-red-400";
                } else if (isAnswerSubmitted && option.isCorrect) {
                  optionClassName += " bg-green-100 border-green-500 dark:bg-green-900 dark:border-green-400";
                }
                
                return (
                  <div key={option.id} className={optionClassName}>
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem 
                        value={option.id} 
                        id={option.id}
                        disabled={isAnswerSubmitted}
                        onClick={() => handleAnswerSelection(option.id)}
                      />
                      <Label 
                        htmlFor={option.id} 
                        className={isAnswerSubmitted && option.isCorrect ? "font-bold" : ""}
                      >
                        {option.text}
                      </Label>
                    </div>
                  </div>
                );
              })}
            </RadioGroup>
            
            {isAnswerSubmitted && (
              <Alert className={isCorrect ? "mt-4 bg-green-100 dark:bg-green-900" : "mt-4 bg-red-100 dark:bg-red-900"}>
                {isCorrect ? (
                  <CheckCircle className="h-4 w-4 text-green-600 dark:text-green-300" />
                ) : (
                  <AlertCircle className="h-4 w-4 text-red-600 dark:text-red-300" />
                )}
                <AlertTitle>
                  {isCorrect ? "Correct!" : "Incorrect"}
                </AlertTitle>
                <AlertDescription>
                  {isCorrect 
                    ? "You've selected the right answer." 
                    : "The correct answer is highlighted above."}
                </AlertDescription>
              </Alert>
            )}
          </CardContent>
          
          <CardFooter>
            {isAnswerSubmitted ? (
              <Button onClick={handleNextQuestion} className="w-full">
                {isLastQuestion ? "See Results" : "Next Question"} 
                <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
            ) : (
              <Button 
                onClick={handleAnswerSubmit} 
                className="w-full"
                disabled={!selectedAnswerId}
              >
                Submit Answer
              </Button>
            )}
          </CardFooter>
        </Card>
      </div>
    </Layout>
  );
}