import React, { useEffect } from 'react';
import { useLocation } from 'wouter';
import { useFormBuilder } from '@/hooks/useFormBuilder';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { apiRequest } from '@/lib/queryClient';
import { useMutation } from '@tanstack/react-query';
import { useToast } from '@/hooks/use-toast';
import { ParserResult } from '@shared/schema';
import { ArrowLeft, ArrowRight } from 'lucide-react';
import ProcessingModal from '@/components/ProcessingModal';

const Process: React.FC = () => {
  const [, navigate] = useLocation();
  const { toast } = useToast();
  const { 
    uploadedFile, 
    setParsedResult,
    setProcessing,
    processing,
    setFormData,
    goToNextStep,
    goToPreviousStep,
    parsedResult 
  } = useFormBuilder();
  
  // Upload and process document mutation
  const { mutate, isPending, isError, error } = useMutation({
    mutationFn: async (): Promise<ParserResult> => {
      if (!uploadedFile) {
        throw new Error('No file to process');
      }
      
      const formData = new FormData();
      formData.append('document', uploadedFile.file);
      
      const response = await fetch('/api/documents/upload', {
        method: 'POST',
        body: formData,
      });
      
      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.message || 'Failed to process document');
      }
      
      return response.json();
    },
    onSuccess: (data) => {
      setParsedResult(data);
      
      // Set the form data from parsed result
      setFormData({
        title: data.title || 'Untitled Form',
        questions: data.questions || [],
      });
      
      // Simulate a delay to show processing steps
      setTimeout(() => {
        setProcessing(false);
        toast({
          title: 'Document processed successfully',
          description: `Extracted ${data.questions.length} questions`,
        });
      }, 1500);
    },
    onError: (err: Error) => {
      setProcessing(false);
      toast({
        variant: 'destructive',
        title: 'Processing failed',
        description: err.message,
      });
    }
  });
  
  // Start processing on page load if we have a file
  useEffect(() => {
    if (uploadedFile && !parsedResult && !processing && !isPending) {
      setProcessing(true);
      mutate();
    }
    
    // Redirect to upload if no file
    if (!uploadedFile) {
      navigate('/upload');
    }
  }, [uploadedFile, parsedResult, processing, isPending]);
  
  const handleBackClick = () => {
    goToPreviousStep();
    navigate('/upload');
  };
  
  const handleContinueClick = () => {
    if (parsedResult) {
      goToNextStep();
      navigate('/edit');
    }
  };
  
  return (
    <div className="max-w-3xl mx-auto">
      <Card className="bg-white shadow rounded-lg">
        <CardHeader>
          <CardTitle className="text-xl font-semibold text-gray-900">Document Processing</CardTitle>
          <CardDescription>
            We're analyzing your document to extract questions, answers, and images.
          </CardDescription>
        </CardHeader>
        
        <CardContent>
          {(processing || isPending) && <ProcessingModal />}
          
          {!processing && !isPending && parsedResult && (
            <div className="bg-green-50 border border-green-200 rounded-lg p-4">
              <h3 className="text-lg font-semibold text-green-800 mb-2">Processing Complete</h3>
              <div className="space-y-2 text-sm text-green-700">
                <p>Successfully extracted {parsedResult.questions.length} questions</p>
                {parsedResult.extractedImages && parsedResult.extractedImages.length > 0 && (
                  <p>Found {parsedResult.extractedImages.length} images</p>
                )}
                {parsedResult.potentialMerges && parsedResult.potentialMerges.length > 0 && (
                  <p>Detected {parsedResult.potentialMerges.length} potential merge suggestions</p>
                )}
              </div>
              
              <div className="mt-4">
                <p className="text-gray-600">
                  You can now edit and customize your form in the next step.
                </p>
              </div>
            </div>
          )}
          
          {!processing && !isPending && isError && (
            <div className="bg-red-50 border border-red-200 rounded-lg p-4">
              <h3 className="text-lg font-semibold text-red-800 mb-2">Processing Failed</h3>
              <p className="text-red-600">
                {error instanceof Error ? error.message : 'An unknown error occurred'}
              </p>
              <Button 
                variant="outline" 
                className="mt-4"
                onClick={() => mutate()}
              >
                Try Again
              </Button>
            </div>
          )}
        </CardContent>
      </Card>
      
      <div className="mt-6 flex justify-between">
        <Button 
          variant="outline" 
          onClick={handleBackClick}
          className="flex items-center"
          disabled={processing || isPending}
        >
          <ArrowLeft className="mr-2 h-4 w-4" />
          Back to Upload
        </Button>
        
        <Button 
          onClick={handleContinueClick}
          disabled={processing || isPending || !parsedResult}
          className="flex items-center"
        >
          Continue to Edit
          <ArrowRight className="ml-2 h-4 w-4" />
        </Button>
      </div>
    </div>
  );
};

export default Process;
