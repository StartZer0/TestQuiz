import React from 'react';
import { useLocation } from 'wouter';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from '@/components/ui/card';
import { FileUp, FileText, Settings, Download } from 'lucide-react';
import { useFormBuilder } from '@/hooks/useFormBuilder';

const Home: React.FC = () => {
  const [, navigate] = useLocation();
  const { setCurrentStep } = useFormBuilder();
  
  const handleStart = () => {
    setCurrentStep(1);
    navigate('/upload');
  };

  return (
    <div className="flex flex-col items-center">
      <div className="text-center max-w-3xl mb-12">
        <h1 className="text-4xl font-bold tracking-tight text-gray-900 sm:text-5xl mb-6">
          Transform Documents into Interactive Forms
        </h1>
        <p className="text-xl text-gray-600">
          Upload your document and let our AI extract questions, answers, and images automatically.
          Edit, customize, and export your form in minutes.
        </p>
        <div className="mt-8">
          <Button onClick={handleStart} size="lg" className="text-lg px-8 py-6">
            <FileUp className="mr-2 h-5 w-5" />
            Get Started
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8 w-full max-w-6xl">
        <Card>
          <CardHeader>
            <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center mb-4">
              <FileUp className="h-6 w-6 text-primary" />
            </div>
            <CardTitle>Upload</CardTitle>
            <CardDescription>
              Start by uploading your Word document (.docx)
            </CardDescription>
          </CardHeader>
          <CardContent>
            <p className="text-gray-600">
              Our system accepts Word documents and automatically extracts content.
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center mb-4">
              <FileText className="h-6 w-6 text-primary" />
            </div>
            <CardTitle>Process</CardTitle>
            <CardDescription>
              AI extracts questions, answers, and images
            </CardDescription>
          </CardHeader>
          <CardContent>
            <p className="text-gray-600">
              Advanced algorithms detect multiple-choice questions, short answers, and embedded images.
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center mb-4">
              <Settings className="h-6 w-6 text-primary" />
            </div>
            <CardTitle>Edit</CardTitle>
            <CardDescription>
              Review and customize your form
            </CardDescription>
          </CardHeader>
          <CardContent>
            <p className="text-gray-600">
              Edit questions, change types, reorder items, and set correct answers with our intuitive editor.
            </p>
          </CardContent>
        </Card>
      </div>

      <div className="w-full max-w-6xl mt-8">
        <Card>
          <CardHeader>
            <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center mb-4">
              <Download className="h-6 w-6 text-primary" />
            </div>
            <CardTitle>Export</CardTitle>
            <CardDescription>
              Download your form in various formats
            </CardDescription>
          </CardHeader>
          <CardContent>
            <p className="text-gray-600">
              Export your form as JSON or integrate with other systems.
            </p>
          </CardContent>
          <CardFooter>
            <Button onClick={handleStart} variant="outline" className="w-full">
              Get Started
            </Button>
          </CardFooter>
        </Card>
      </div>
    </div>
  );
};

export default Home;
