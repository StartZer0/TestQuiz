import React, { useState } from 'react';
import { useLocation } from 'wouter';
import { useFormBuilder } from '@/hooks/useFormBuilder';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { ArrowLeft, FileJson, Download, Copy, Check, Save } from 'lucide-react';
import { useMutation } from '@tanstack/react-query';
import { useToast } from '@/hooks/use-toast';
import { apiRequest } from '@/lib/queryClient';

const Export: React.FC = () => {
  const [, navigate] = useLocation();
  const { formData, goToPreviousStep } = useFormBuilder();
  const { toast } = useToast();
  const [copied, setCopied] = useState(false);
  
  // Save form mutation
  const { mutate: saveForm, isPending } = useMutation({
    mutationFn: async () => {
      const response = await apiRequest('POST', '/api/forms', formData);
      return await response.json();
    },
    onSuccess: (data) => {
      toast({
        title: 'Form saved successfully',
        description: `Form ID: ${data.id}`,
      });
    },
    onError: (error: Error) => {
      toast({
        variant: 'destructive',
        title: 'Failed to save form',
        description: error.message,
      });
    },
  });
  
  const handleExportJSON = () => {
    const dataStr = JSON.stringify(formData, null, 2);
    const dataUri = 'data:application/json;charset=utf-8,'+ encodeURIComponent(dataStr);
    const exportFileDefaultName = `${formData.title.replace(/\s+/g, '_')}_${new Date().toISOString().split('T')[0]}.json`;
    
    const linkElement = document.createElement('a');
    linkElement.setAttribute('href', dataUri);
    linkElement.setAttribute('download', exportFileDefaultName);
    linkElement.click();
  };
  
  const handleCopyJSON = () => {
    const dataStr = JSON.stringify(formData, null, 2);
    navigator.clipboard.writeText(dataStr).then(() => {
      setCopied(true);
      toast({
        title: 'Copied to clipboard',
        description: 'JSON data has been copied to your clipboard',
      });
      setTimeout(() => setCopied(false), 2000);
    }).catch(err => {
      toast({
        variant: 'destructive',
        title: 'Failed to copy',
        description: 'Could not copy to clipboard',
      });
    });
  };
  
  const handleBackClick = () => {
    goToPreviousStep();
    navigate('/edit');
  };
  
  const formatJSON = (data: any) => {
    return JSON.stringify(data, null, 2);
  };
  
  return (
    <div className="max-w-4xl mx-auto">
      <Card className="bg-white shadow rounded-lg">
        <CardHeader>
          <CardTitle className="text-xl font-semibold text-gray-900">Export Form</CardTitle>
          <CardDescription>
            Choose how you want to export your form.
          </CardDescription>
        </CardHeader>
        
        <CardContent>
          <Tabs defaultValue="json" className="w-full">
            <TabsList className="mb-4">
              <TabsTrigger value="json">JSON</TabsTrigger>
              <TabsTrigger value="preview">Preview</TabsTrigger>
            </TabsList>
            
            <TabsContent value="json" className="p-4 bg-gray-50 rounded-lg">
              <div className="flex justify-between items-center mb-4">
                <h3 className="text-lg font-medium">JSON Data</h3>
                <div className="flex space-x-2">
                  <Button 
                    variant="outline" 
                    size="sm" 
                    onClick={handleCopyJSON}
                    className="flex items-center"
                  >
                    {copied ? (
                      <>
                        <Check className="h-4 w-4 mr-2" />
                        Copied
                      </>
                    ) : (
                      <>
                        <Copy className="h-4 w-4 mr-2" />
                        Copy JSON
                      </>
                    )}
                  </Button>
                  <Button 
                    variant="outline" 
                    size="sm" 
                    onClick={handleExportJSON}
                    className="flex items-center"
                  >
                    <Download className="h-4 w-4 mr-2" />
                    Download JSON
                  </Button>
                </div>
              </div>
              
              <div className="border rounded-md bg-gray-900 text-gray-100 p-4 overflow-x-auto">
                <pre className="text-sm">
                  <code>{formatJSON(formData)}</code>
                </pre>
              </div>
              
              <div className="mt-6">
                <Button 
                  onClick={() => saveForm()}
                  disabled={isPending}
                  className="w-full flex items-center justify-center"
                >
                  <Save className="h-4 w-4 mr-2" />
                  {isPending ? 'Saving...' : 'Save Form'}
                </Button>
              </div>
            </TabsContent>
            
            <TabsContent value="preview">
              <div className="p-6 bg-gray-50 rounded-lg">
                <h2 className="text-2xl font-bold mb-6">{formData.title}</h2>
                
                {formData.questions.map((question, index) => (
                  <div key={question.id} className="mb-6 p-4 bg-white rounded-lg shadow">
                    <div className="flex items-start justify-between">
                      <div>
                        <p className="font-medium mb-2">{question.text}</p>
                        
                        {question.imageUrl && (
                          <div className="mb-3">
                            <img 
                              src={question.imageUrl} 
                              alt="Question visual" 
                              className="max-w-full h-auto rounded-md border"
                            />
                          </div>
                        )}
                        
                        {question.type === 'multiple-choice' && question.options && (
                          <div className="space-y-2 mt-3">
                            {question.options.map((option) => (
                              <div key={option.id} className="flex items-center">
                                <input 
                                  type="radio" 
                                  name={`question-${index}`}
                                  className="h-4 w-4 text-primary border-gray-300"
                                  readOnly
                                  checked={option.isCorrect}
                                />
                                <span className="ml-2">
                                  {option.text}
                                  {option.imageUrl && (
                                    <img 
                                      src={option.imageUrl} 
                                      alt="Option visual" 
                                      className="max-w-full h-auto mt-1 rounded"
                                    />
                                  )}
                                </span>
                              </div>
                            ))}
                          </div>
                        )}
                        
                        {question.type === 'short-answer' && (
                          <div className="mt-2">
                            <input 
                              type="text" 
                              className="w-full border-gray-300 rounded-md shadow-sm"
                              placeholder="Short answer text"
                              readOnly
                            />
                          </div>
                        )}
                        
                        {question.type === 'paragraph' && (
                          <div className="mt-2">
                            <textarea 
                              className="w-full border-gray-300 rounded-md shadow-sm" 
                              rows={3}
                              placeholder="Paragraph answer text"
                              readOnly
                            ></textarea>
                          </div>
                        )}
                      </div>
                      
                      {question.points > 0 && (
                        <div className="text-sm text-gray-500">
                          {question.points} {question.points === 1 ? 'point' : 'points'}
                        </div>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
      
      <div className="mt-6 flex justify-between">
        <Button
          variant="outline"
          onClick={handleBackClick}
          className="flex items-center"
        >
          <ArrowLeft className="h-4 w-4 mr-2" />
          Back to Edit
        </Button>
        
        <Button
          onClick={() => navigate('/')}
          className="flex items-center"
        >
          Start New Form
        </Button>
      </div>
    </div>
  );
};

export default Export;
