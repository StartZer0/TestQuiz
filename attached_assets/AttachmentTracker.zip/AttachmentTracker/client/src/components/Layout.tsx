import React from 'react';
import Header from './Header';
import { useFormBuilder } from '@/hooks/useFormBuilder';
import StepIndicator from './StepIndicator';
import { useLocation } from 'wouter';

interface LayoutProps {
  children: React.ReactNode;
}

const Layout: React.FC<LayoutProps> = ({ children }) => {
  const { currentStep } = useFormBuilder();
  const [location] = useLocation();
  
  // Only show the step indicator on workflow pages
  const showStepIndicator = ['/upload', '/process', '/edit', '/export'].includes(location);
  
  // Don't show step indicator on the quiz page
  const isQuizPage = location === '/quiz';
  
  const stepLabels = ['Upload', 'Process', 'Edit', 'Export'];

  return (
    <div className="bg-gray-50 min-h-screen flex flex-col">
      <Header />
      <main className="flex-grow">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          {showStepIndicator && (
            <div className="mb-8">
              <StepIndicator 
                currentStep={currentStep} 
                totalSteps={4} 
                stepLabels={stepLabels} 
              />
            </div>
          )}
          {children}
        </div>
      </main>
    </div>
  );
};

export default Layout;
