import React from 'react';
import { Check } from 'lucide-react';
import { StepProps } from '@/types';

const StepIndicator: React.FC<StepProps> = ({ currentStep, totalSteps, stepLabels }) => {
  return (
    <div className="flex items-center justify-between">
      {Array.from({ length: totalSteps }, (_, i) => i + 1).map((step) => (
        <React.Fragment key={step}>
          {/* Step Circle */}
          <div className="flex flex-col items-center">
            <div 
              className={`w-10 h-10 rounded-full border-2 flex items-center justify-center mb-2 ${
                step < currentStep 
                  ? 'bg-primary border-primary text-white' // Completed
                  : step === currentStep 
                  ? 'border-primary text-primary' // Active
                  : 'border-gray-300 text-gray-500' // Inactive
              }`}
            >
              {step < currentStep ? (
                <Check className="h-5 w-5" />
              ) : (
                <span className="text-sm font-medium">{step}</span>
              )}
            </div>
            <span 
              className={`text-sm font-medium ${
                step <= currentStep ? 'text-gray-900' : 'text-gray-500'
              }`}
            >
              {stepLabels[step - 1]}
            </span>
          </div>
          
          {/* Connector Line (don't show after last step) */}
          {step < totalSteps && (
            <div 
              className={`flex-1 h-0.5 mx-2 ${
                step < currentStep ? 'bg-primary' : 'bg-gray-200'
              }`}
            />
          )}
        </React.Fragment>
      ))}
    </div>
  );
};

export default StepIndicator;
