import React from 'react';
import { Droppable } from 'react-beautiful-dnd';
import { useFormBuilder } from '@/hooks/useFormBuilder';
import DraggableQuestionItem from './DraggableQuestionItem';
import { Button } from '@/components/ui/button';
import { PlusCircle } from 'lucide-react';

interface QuestionListProps {
  onMergeItems: (indices: number[]) => void;
  onAddQuestion: () => void;
}

const QuestionList: React.FC<QuestionListProps> = ({ onMergeItems, onAddQuestion }) => {
  const { formData, parsedResult } = useFormBuilder();
  
  // Function to check if question has a merge suggestion
  const hasMergeSuggestion = (index: number) => {
    if (!parsedResult || !parsedResult.potentialMerges) return false;
    
    return parsedResult.potentialMerges.some(
      (merge) => merge.sourceIndex === index || merge.targetIndex === index
    );
  };
  
  // Function to get merge suggestion for a question
  const getMergeSuggestion = (index: number) => {
    if (!parsedResult || !parsedResult.potentialMerges) return null;
    
    return parsedResult.potentialMerges.find(
      (merge) => merge.sourceIndex === index || merge.targetIndex === index
    );
  };

  return (
    <div className="px-6 py-4 overflow-y-auto max-h-[calc(100vh-300px)]">
      <Droppable droppableId="questions">
        {(provided) => (
          <div
            {...provided.droppableProps}
            ref={provided.innerRef}
            className="space-y-4"
          >
            {formData.questions.map((question, index) => {
              const mergeSuggestion = getMergeSuggestion(index);
              const mergeIndices = mergeSuggestion 
                ? [mergeSuggestion.sourceIndex, mergeSuggestion.targetIndex]
                : [];
              
              return (
                <DraggableQuestionItem
                  key={question.id}
                  question={question}
                  index={index}
                  hasMergeSuggestion={hasMergeSuggestion(index)}
                  onMergeItems={mergeIndices.length > 0 ? () => onMergeItems(mergeIndices) : undefined}
                />
              );
            })}
            {provided.placeholder}
          </div>
        )}
      </Droppable>
      
      <Button 
        onClick={onAddQuestion}
        variant="outline" 
        className="w-full border-2 border-dashed border-gray-300 rounded-lg p-4 mt-4 text-gray-500 font-medium hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent flex items-center justify-center"
      >
        <PlusCircle className="mr-2 h-5 w-5" />
        Add Question
      </Button>
    </div>
  );
};

export default QuestionList;
