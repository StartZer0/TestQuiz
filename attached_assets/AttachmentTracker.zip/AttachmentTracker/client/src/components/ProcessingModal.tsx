import React, { useState, useEffect } from 'react';

const ProcessingModal: React.FC = () => {
  const [progress, setProgress] = useState(0);
  const [statusText, setStatusText] = useState('Preparing document...');
  
  // Simulate processing steps
  useEffect(() => {
    const steps = [
      { progress: 10, text: 'Preparing document...' },
      { progress: 25, text: 'Extracting text content...' },
      { progress: 40, text: 'Identifying questions...' },
      { progress: 60, text: 'Extracting answer options...' },
      { progress: 75, text: 'Processing images...' },
      { progress: 90, text: 'Finalizing extraction...' },
      { progress: 100, text: 'Almost done...' },
    ];
    
    let currentStep = 0;
    
    const interval = setInterval(() => {
      if (currentStep < steps.length) {
        setProgress(steps[currentStep].progress);
        setStatusText(steps[currentStep].text);
        currentStep++;
      } else {
        clearInterval(interval);
      }
    }, 800);
    
    return () => clearInterval(interval);
  }, []);
  
  return (
    <div className="flex flex-col items-center py-8">
      <div className="animate-spin rounded-full h-12 w-12 border-4 border-primary-200 border-t-primary mb-4"></div>
      <h3 className="text-lg font-medium text-gray-900 mb-1">Processing Document</h3>
      <p className="text-gray-600 text-center mb-4">
        {statusText}
      </p>
      <div className="w-full max-w-md bg-gray-200 rounded-full h-2.5">
        <div 
          className="bg-primary h-2.5 rounded-full" 
          style={{ width: `${progress}%` }}
        ></div>
      </div>
      <p className="text-gray-500 text-sm mt-2">This may take a few moments...</p>
    </div>
  );
};

export default ProcessingModal;
