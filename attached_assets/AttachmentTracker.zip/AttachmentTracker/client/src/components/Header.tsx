import React from 'react';
import { Link } from 'wouter';
import { FileText } from 'lucide-react';

const Header: React.FC = () => {
  return (
    <header className="bg-white shadow">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex justify-between items-center">
        <div className="flex items-center">
          <FileText className="h-6 w-6 text-primary mr-2" />
          <h1 className="text-xl font-semibold text-gray-900">FormBuilder Pro</h1>
        </div>
        <nav>
          <ul className="flex space-x-6">
            <li><Link href="/" className="text-gray-600 hover:text-primary">Home</Link></li>
            <li><Link href="/upload" className="text-gray-600 hover:text-primary">Templates</Link></li>
            <li><Link href="/quiz" className="text-gray-600 hover:text-primary">Take Test</Link></li>
            <li><a href="#" className="text-gray-600 hover:text-primary">Help</a></li>
            <li><a href="#" className="text-gray-600 hover:text-primary">Account</a></li>
          </ul>
        </nav>
      </div>
    </header>
  );
};

export default Header;
