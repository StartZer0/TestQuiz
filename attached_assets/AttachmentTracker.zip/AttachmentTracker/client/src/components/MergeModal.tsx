import React, { useState } from 'react';
import { useFormBuilder } from '@/hooks/useFormBuilder';
import { Question } from '@shared/schema';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Checkbox } from '@/components/ui/checkbox';
import { Label } from '@/components/ui/label';
import { X, Merge } from 'lucide-react';

interface MergeModalProps {
  isOpen: boolean;
  onClose: () => void;
  selectedIndices: number[];
  questions: Question[];
}

const MergeModal: React.FC<MergeModalProps> = ({
  isOpen,
  onClose,
  selectedIndices,
  questions
}) => {
  const { mergeItems } = useFormBuilder();
  const [checkedIndices, setCheckedIndices] = useState<number[]>(selectedIndices);
  
  const handleCheckboxChange = (index: number, checked: boolean) => {
    if (checked) {
      setCheckedIndices([...checkedIndices, index]);
    } else {
      setCheckedIndices(checkedIndices.filter(i => i !== index));
    }
  };
  
  const handleMerge = () => {
    if (checkedIndices.length >= 2) {
      mergeItems(checkedIndices);
      onClose();
    }
  };
  
  const handleClose = () => {
    // Reset checked indices to original selection
    setCheckedIndices(selectedIndices);
    onClose();
  };
  
  // Get question type as readable text
  const getQuestionTypeText = (type: Question['type']) => {
    switch (type) {
      case 'multiple-choice': return 'Multiple Choice';
      case 'short-answer': return 'Short Answer';
      case 'paragraph': return 'Paragraph';
      case 'checkbox': return 'Checkbox';
      case 'dropdown': return 'Dropdown';
      default: return type;
    }
  };
  
  // Get item summary text
  const getItemSummary = (question: Question) => {
    if (question.imageUrl && !question.text) {
      return 'Image item';
    }
    
    let summary = `${getQuestionTypeText(question.type)}`;
    
    if (question.options) {
      summary += ` • ${question.options.length} options`;
    }
    
    return summary;
  };
  
  return (
    <Dialog open={isOpen} onOpenChange={handleClose}>
      <DialogContent className="sm:max-w-lg">
        <DialogHeader>
          <DialogTitle>Merge Items</DialogTitle>
          <DialogDescription>
            Select the items you want to merge together. This will combine them into a single question.
          </DialogDescription>
        </DialogHeader>
        
        <div className="max-h-80 overflow-y-auto my-4">
          {questions.map((question, index) => (
            <div key={question.id} className="flex items-center p-3 border rounded-md mb-2 bg-gray-50">
              <Checkbox
                id={`merge-checkbox-${index}`}
                checked={checkedIndices.includes(index)}
                onCheckedChange={(checked) => handleCheckboxChange(index, !!checked)}
                className="h-4 w-4 mr-3"
              />
              <div>
                <Label 
                  htmlFor={`merge-checkbox-${index}`}
                  className="text-sm font-medium cursor-pointer"
                >
                  {question.text ? (
                    `Question: ${question.text.length > 60 ? question.text.substring(0, 60) + '...' : question.text}`
                  ) : (
                    'Image item'
                  )}
                </Label>
                <p className="text-xs text-gray-500">{getItemSummary(question)}</p>
              </div>
            </div>
          ))}
        </div>
        
        <DialogFooter className="flex justify-end space-x-3">
          <Button variant="outline" onClick={handleClose}>
            Cancel
          </Button>
          <Button 
            onClick={handleMerge}
            disabled={checkedIndices.length < 2}
            className="flex items-center"
          >
            <Merge className="h-4 w-4 mr-2" />
            Merge Selected Items
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

export default MergeModal;
