import React, { useState } from 'react';
import { Edit } from 'lucide-react';
import { Button } from '@/components/ui/button';

interface ImagePreviewProps {
  src: string;
  alt: string;
  onEdit?: () => void;
}

const ImagePreview: React.FC<ImagePreviewProps> = ({ src, alt, onEdit }) => {
  const [error, setError] = useState(false);
  
  // Handle image load error
  const handleError = () => {
    setError(true);
  };
  
  if (error) {
    return (
      <div className="relative border rounded-md bg-gray-100 p-4 flex items-center justify-center h-32">
        <p className="text-gray-500">Failed to load image</p>
      </div>
    );
  }
  
  return (
    <div className="relative border rounded-md overflow-hidden">
      <img 
        src={src} 
        alt={alt} 
        className="w-full h-auto" 
        onError={handleError}
      />
      {onEdit && (
        <Button
          variant="secondary"
          size="icon"
          className="absolute top-2 right-2 bg-gray-800 bg-opacity-70 text-white hover:bg-opacity-80"
          onClick={onEdit}
        >
          <Edit className="h-4 w-4" />
        </Button>
      )}
    </div>
  );
};

export default ImagePreview;
