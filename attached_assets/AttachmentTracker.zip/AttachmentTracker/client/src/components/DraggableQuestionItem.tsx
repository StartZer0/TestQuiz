import React from 'react';
import { Draggable } from 'react-beautiful-dnd';
import { useFormBuilder } from '@/hooks/useFormBuilder';
import { Question } from '@shared/schema';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Checkbox } from '@/components/ui/checkbox';
import { Label } from '@/components/ui/label';
import { nanoid } from 'nanoid';
import { GripVertical, Copy, Trash, Edit, Info, Merge } from 'lucide-react';
import ImagePreview from './ImagePreview';

interface DraggableQuestionItemProps {
  question: Question;
  index: number;
  hasMergeSuggestion?: boolean;
  onMergeItems?: () => void;
}

const DraggableQuestionItem: React.FC<DraggableQuestionItemProps> = ({
  question,
  index,
  hasMergeSuggestion = false,
  onMergeItems,
}) => {
  const {
    updateQuestionType,
    updateQuestionText,
    updateQuestionRequired,
    updateQuestionPoints,
    updateQuestionCorrectAnswer,
    addOption,
    updateOption,
    removeOption,
    setCorrectOption,
    removeQuestion,
  } = useFormBuilder();

  const handleAddOption = () => {
    addOption(index, {
      id: nanoid(),
      text: '',
      isCorrect: false,
    });
  };

  const handleDuplicateQuestion = () => {
    // Clone the current question with a new ID
    const newQuestion = {
      ...question,
      id: nanoid(),
      options: question.options?.map(opt => ({ ...opt, id: nanoid() })),
    };
    
    // Add the cloned question
    useFormBuilder().addQuestion(newQuestion);
  };

  return (
    <Draggable draggableId={question.id} index={index}>
      {(provided) => (
        <div
          ref={provided.innerRef}
          {...provided.draggableProps}
          className="bg-gray-50 rounded-lg p-4 border border-gray-200"
        >
          <div className="flex items-start">
            <div
              {...provided.dragHandleProps}
              className="drag-handle mr-3 text-gray-400 self-center"
            >
              <GripVertical />
            </div>
            
            <div className="flex-1">
              <div className="flex flex-wrap items-start mb-4 gap-4">
                <div className="flex-1 min-w-[200px]">
                  <Label className="block text-sm font-medium text-gray-700 mb-1">
                    Question Type
                  </Label>
                  <Select
                    value={question.type}
                    onValueChange={(value) => updateQuestionType(index, value as Question['type'])}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select question type" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="multiple-choice">Multiple Choice</SelectItem>
                      <SelectItem value="short-answer">Short Answer</SelectItem>
                      <SelectItem value="paragraph">Paragraph</SelectItem>
                      <SelectItem value="checkbox">Checkbox</SelectItem>
                      <SelectItem value="dropdown">Dropdown</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <div className="w-28">
                  <Label className="block text-sm font-medium text-gray-700 mb-1">
                    Points
                  </Label>
                  <Input
                    type="number"
                    value={question.points}
                    onChange={(e) => updateQuestionPoints(index, parseInt(e.target.value) || 0)}
                    min={0}
                    className="block w-full"
                  />
                </div>
                
                <div className="flex items-center mt-6">
                  <Checkbox
                    id={`required-${index}`}
                    checked={question.required}
                    onCheckedChange={(checked) => updateQuestionRequired(index, !!checked)}
                  />
                  <Label htmlFor={`required-${index}`} className="ml-2 text-sm text-gray-700">
                    Required
                  </Label>
                </div>
              </div>
              
              <div className="mb-4">
                <Label className="block text-sm font-medium text-gray-700 mb-1">
                  Question Text
                </Label>
                <Textarea
                  value={question.text}
                  onChange={(e) => updateQuestionText(index, e.target.value)}
                  rows={2}
                  className="block w-full"
                />
              </div>
              
              {question.imageUrl && (
                <div className="mb-4">
                  <ImagePreview src={question.imageUrl} alt="Question image" />
                </div>
              )}
              
              {(question.type === 'multiple-choice' || question.type === 'checkbox' || question.type === 'dropdown') && (
                <div className="mb-2">
                  <Label className="block text-sm font-medium text-gray-700 mb-1">
                    Answer Options
                  </Label>
                  
                  {question.options?.map((option, optionIndex) => (
                    <div key={option.id} className="flex items-center mb-2">
                      <input
                        type={question.type === 'checkbox' ? 'checkbox' : 'radio'}
                        name={`correct-${question.id}`}
                        className="h-4 w-4 border-gray-300 text-primary focus:ring-primary"
                        checked={option.isCorrect}
                        onChange={() => setCorrectOption(index, optionIndex)}
                      />
                      <Input
                        className="ml-2 flex-1"
                        value={option.text}
                        onChange={(e) => updateOption(index, optionIndex, { ...option, text: e.target.value })}
                      />
                      
                      <Button
                        variant="ghost"
                        size="icon"
                        className="ml-2 text-gray-400 hover:text-gray-600"
                        onClick={() => removeOption(index, optionIndex)}
                      >
                        <Trash className="h-4 w-4" />
                      </Button>
                    </div>
                  ))}
                  
                  <Button
                    variant="link"
                    className="text-primary mt-2 flex items-center text-sm font-medium p-0"
                    onClick={handleAddOption}
                  >
                    <PlusCircle className="h-4 w-4 mr-1" />
                    Add Option
                  </Button>
                </div>
              )}
              
              {question.type === 'short-answer' && (
                <div className="mb-2">
                  <Label className="block text-sm font-medium text-gray-700 mb-1">
                    Accepted Answer (Optional)
                  </Label>
                  <Input
                    value={question.correctAnswer || ''}
                    onChange={(e) => updateQuestionCorrectAnswer(index, e.target.value)}
                    placeholder="Enter correct answer"
                    className="block w-full"
                  />
                  <p className="mt-1 text-sm text-gray-500">
                    This will be used for automatic grading if enabled.
                  </p>
                </div>
              )}
              
              {/* Merge notification */}
              {hasMergeSuggestion && onMergeItems && (
                <div className="mt-4 p-3 bg-blue-50 border border-blue-200 rounded-md flex items-start">
                  <Info className="h-5 w-5 text-blue-600 mr-2 flex-shrink-0" />
                  <div>
                    <h4 className="text-sm font-medium text-blue-800">Potential Item to Merge</h4>
                    <p className="text-sm text-blue-700 mt-1">
                      We detected an item that might belong with this question. Would you like to merge it?
                    </p>
                    <div className="mt-2 flex space-x-2">
                      <Button
                        size="sm"
                        className="bg-primary hover:bg-primary/90 text-white text-sm py-1 px-3 rounded-md flex items-center"
                        onClick={onMergeItems}
                      >
                        <Merge className="h-3 w-3 mr-1" />
                        Merge Item
                      </Button>
                      <Button
                        size="sm"
                        variant="ghost"
                        className="bg-gray-200 hover:bg-gray-300 text-gray-800 text-sm py-1 px-3 rounded-md"
                      >
                        Ignore
                      </Button>
                    </div>
                  </div>
                </div>
              )}
            </div>
            
            <div className="ml-4 flex flex-col">
              <Button
                variant="ghost"
                size="icon"
                className="text-gray-400 hover:text-gray-600 mb-2"
                onClick={handleDuplicateQuestion}
              >
                <Copy className="h-5 w-5" />
              </Button>
              <Button
                variant="ghost"
                size="icon"
                className="text-gray-400 hover:text-gray-600"
                onClick={() => removeQuestion(index)}
              >
                <Trash className="h-5 w-5" />
              </Button>
            </div>
          </div>
        </div>
      )}
    </Draggable>
  );
};

// Import PlusCircle icon
import { PlusCircle } from 'lucide-react';

export default DraggableQuestionItem;
