import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Upload, File } from 'lucide-react';
import { DocumentFile } from '@/types';

interface UploadFileProps {
  onFileSelected: (file: DocumentFile | null) => void;
  uploadedFile: DocumentFile | null;
}

const UploadFile: React.FC<UploadFileProps> = ({ onFileSelected, uploadedFile }) => {
  const [dragActive, setDragActive] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  
  // Handle drag events
  const handleDrag = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === 'dragenter' || e.type === 'dragover') {
      setDragActive(true);
    } else if (e.type === 'dragleave') {
      setDragActive(false);
    }
  };
  
  // Handle drop event
  const handleDrop = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      handleFile(e.dataTransfer.files[0]);
    }
  };
  
  // Handle file input change
  const handleFileInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      handleFile(e.target.files[0]);
    }
  };
  
  // Process the file
  const handleFile = (file: File) => {
    setError(null);
    
    // Check file type
    if (!file.name.endsWith('.docx')) {
      setError('Only .docx files are currently supported.');
      return;
    }
    
    // Check file size (max 10MB)
    if (file.size > 10 * 1024 * 1024) {
      setError('File size exceeds the 10MB limit.');
      return;
    }
    
    // Set the uploaded file
    const documentFile: DocumentFile = {
      name: file.name,
      size: file.size,
      type: file.type,
      file: file
    };
    
    onFileSelected(documentFile);
  };
  
  const clearFile = () => {
    onFileSelected(null);
  };
  
  return (
    <>
      {error && (
        <div className="bg-red-50 border-l-4 border-red-500 p-4 mb-4">
          <div className="flex">
            <div className="flex-shrink-0">
              <svg className="h-5 w-5 text-red-400" viewBox="0 0 20 20" fill="currentColor">
                <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z" clipRule="evenodd" />
              </svg>
            </div>
            <div className="ml-3">
              <p className="text-sm text-red-700">{error}</p>
            </div>
          </div>
        </div>
      )}
      
      {!uploadedFile ? (
        <div 
          className={`border-2 border-dashed rounded-lg p-8 text-center ${
            dragActive ? 'border-primary bg-primary/5' : 'border-gray-300'
          }`}
          onDragEnter={handleDrag}
          onDragOver={handleDrag}
          onDragLeave={handleDrag}
          onDrop={handleDrop}
        >
          <Upload className="h-10 w-10 text-gray-400 mx-auto mb-4" />
          <h3 className="text-lg font-medium text-gray-900 mb-1">Drag and drop your file here</h3>
          <p className="text-gray-500 mb-4">Or click to browse files</p>
          
          <input 
            type="file" 
            id="file-upload" 
            className="hidden" 
            accept=".docx" 
            onChange={handleFileInputChange}
          />
          <Button 
            variant="outline" 
            onClick={() => document.getElementById('file-upload')?.click()}
          >
            Browse Files
          </Button>
          
          <p className="text-xs text-gray-400 mt-4">
            Supported format: .docx (Microsoft Word) • Maximum size: 10MB
          </p>
        </div>
      ) : (
        <div className="bg-gray-50 rounded-lg p-4 border border-gray-200">
          <div className="flex items-center">
            <div className="bg-primary/10 p-2 rounded-md mr-3">
              <File className="h-6 w-6 text-primary" />
            </div>
            <div className="flex-1 min-w-0">
              <h4 className="text-sm font-medium text-gray-900 truncate">{uploadedFile.name}</h4>
              <p className="text-xs text-gray-500">
                {(uploadedFile.size / 1024).toFixed(1)} KB • {uploadedFile.type}
              </p>
            </div>
            <Button 
              variant="ghost" 
              size="sm" 
              onClick={clearFile}
              className="text-gray-500"
            >
              Remove
            </Button>
          </div>
        </div>
      )}
    </>
  );
};

export default UploadFile;
