import React from 'react';
import { DragDropContext, DropResult } from 'react-beautiful-dnd';
import { useFormBuilder } from '@/hooks/useFormBuilder';

interface DragProviderProps {
  children: React.ReactNode;
}

const DragProvider: React.FC<DragProviderProps> = ({ children }) => {
  const { reorderQuestions } = useFormBuilder();
  
  // Handle drag end event
  const handleDragEnd = (result: DropResult) => {
    if (!result.destination) return;
    
    // Only reorder questions if they are in the same list
    if (result.type === 'QUESTION' && result.source.droppableId === result.destination.droppableId) {
      reorderQuestions(result.source.index, result.destination.index);
    }
  };
  
  return (
    <DragDropContext onDragEnd={handleDragEnd}>
      {children}
    </DragDropContext>
  );
};

export default DragProvider;
