import { Switch, Route } from "wouter";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { queryClient } from "./lib/queryClient";
import NotFound from "@/pages/not-found";
import Home from "@/pages/Home";
import Upload from "@/pages/Upload";
import Process from "@/pages/Process";
import Edit from "@/pages/Edit";
import Export from "@/pages/Export";
import Quiz from "@/pages/Quiz";
import Layout from "@/components/Layout";
import { FormBuilderProvider } from "@/hooks/useFormBuilder";

function Router() {
  return (
    <Switch>
      <Route path="/" component={Home} />
      <Route path="/upload" component={Upload} />
      <Route path="/process" component={Process} />
      <Route path="/edit" component={Edit} />
      <Route path="/export" component={Export} />
      <Route path="/quiz" component={Quiz} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <FormBuilderProvider>
        <Layout>
          <Router />
        </Layout>
      </FormBuilderProvider>
      <Toaster />
    </QueryClientProvider>
  );
}

export default App;
