import { Question, Option, FormData, ParserResult } from "@shared/schema";

export interface StepProps {
  currentStep: number;
  totalSteps: number;
  stepLabels: string[];
}

export interface DocumentFile {
  name: string;
  size: number;
  type: string;
  file: File;
}

export interface MergeItem {
  sourceIndex: number;
  targetIndex: number;
  reason: string;
}

export interface FormBuilderContextType {
  formData: FormData;
  uploadedFile: DocumentFile | null;
  parsedResult: ParserResult | null;
  processing: boolean;
  currentStep: number;
  
  // Document upload actions
  setUploadedFile: (file: DocumentFile | null) => void;
  
  // Processing actions
  setParsedResult: (result: ParserResult | null) => void;
  setProcessing: (processing: boolean) => void;
  
  // Form data actions
  setFormData: (data: FormData) => void;
  setFormTitle: (title: string) => void;
  addQuestion: (question: Question) => void;
  updateQuestion: (index: number, question: Question) => void;
  removeQuestion: (index: number) => void;
  reorderQuestions: (startIndex: number, endIndex: number) => void;
  
  // Question actions
  updateQuestionType: (index: number, type: Question['type']) => void;
  updateQuestionText: (index: number, text: string) => void;
  updateQuestionImage: (index: number, imageUrl: string) => void;
  updateQuestionRequired: (index: number, required: boolean) => void;
  updateQuestionPoints: (index: number, points: number) => void;
  updateQuestionCorrectAnswer: (index: number, answer: string) => void;
  
  // Options actions
  addOption: (questionIndex: number, option: Option) => void;
  updateOption: (questionIndex: number, optionIndex: number, option: Option) => void;
  removeOption: (questionIndex: number, optionIndex: number) => void;
  setCorrectOption: (questionIndex: number, optionIndex: number) => void;
  
  // Navigation
  goToNextStep: () => void;
  goToPreviousStep: () => void;
  setCurrentStep: (step: number) => void;
  
  // Merge items
  mergeItems: (indices: number[]) => void;
}
