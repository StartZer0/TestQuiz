import { 
  users, 
  type User, 
  type InsertUser, 
  forms, 
  type Form,
  type InsertForm,
  type FormData
} from "@shared/schema";

// Storage interface
export interface IStorage {
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  createForm(form: FormData): Promise<Form>;
  getForm(id: number): Promise<Form | undefined>;
  getForms(userId?: number): Promise<Form[]>;
}

// In-memory storage implementation
export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private forms: Map<number, Form>;
  private userCurrentId: number;
  private formCurrentId: number;

  constructor() {
    this.users = new Map();
    this.forms = new Map();
    this.userCurrentId = 1;
    this.formCurrentId = 1;
  }

  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.userCurrentId++;
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  async createForm(formData: FormData): Promise<Form> {
    const id = this.formCurrentId++;
    const form: Form = {
      id,
      title: formData.title,
      createdAt: new Date().toISOString(),
      questions: formData.questions,
      userId: undefined, // In a real app, this would be set from the authenticated user
    };
    
    this.forms.set(id, form);
    return form;
  }

  async getForm(id: number): Promise<Form | undefined> {
    return this.forms.get(id);
  }

  async getForms(userId?: number): Promise<Form[]> {
    if (userId) {
      return Array.from(this.forms.values()).filter(
        (form) => form.userId === userId,
      );
    }
    return Array.from(this.forms.values());
  }
}

// Create storage instance
export const storage = new MemStorage();
