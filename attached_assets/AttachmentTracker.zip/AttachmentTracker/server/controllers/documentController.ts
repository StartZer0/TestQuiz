import { UploadDocument, ParserResult, Question, ExplanatoryItem } from "@shared/schema";
import { documentParser } from "../services/documentParser";
import { imageExtractor } from "../services/imageExtractor";
import path from "path";
import fs from "fs";
import { nanoid } from "nanoid";

// Controller for document processing
export const documentController = {
  // Process uploaded document
  async processDocument(data: UploadDocument): Promise<ParserResult> {
    const { fileName } = data;
    
    // Get full path to uploaded file
    const filePath = path.join(process.cwd(), "uploads", fileName);
    
    // Check if file exists
    if (!fs.existsSync(filePath)) {
      throw new Error("File not found");
    }
    
    try {
      // Parse document to extract text and structure
      const parsedContent = await documentParser.parseDocument(filePath);
      
      // Extract images from the document
      const extractedImages = await imageExtractor.extractImages(filePath);
      
      // Process the content to identify questions, answers, etc.
      const questions: Question[] = [];
      let title = "Untitled Form";
      
      // Extract title if present (first paragraph or heading)
      if (parsedContent.value && parsedContent.value.length > 0) {
        title = parsedContent.value.split('\n')[0].trim();
      }
      
      // Process the content for complex question formats
      const content = parsedContent.value;
      
      console.log("Content length for parsing:", content.length);
      console.log("Document preview:", content.substring(0, 200)); 
      
      // NEW APPROACH: Use a simpler line-by-line parsing method
      // Split the document by lines
      const lines = content.split('\n').filter(line => line.trim().length > 0);
      
      // Iterate through lines to find questions and options
      let currentQuestion: Question | null = null;
      let explanatoryItems: ExplanatoryItem[] = [];
      let collectingExplanatoryItems = false;
      
      for (let i = 0; i < lines.length; i++) {
        const line = lines[i].trim();
        console.log(`Processing line ${i}: ${line.substring(0, 50)}...`);
        
        // Check if line is a question (format like "301) Question text")
        const questionMatch = line.match(/^(\d{3}[\.\)])\s*(.*)/);
        if (questionMatch) {
          // If we were processing a previous question, add it to our list
          if (currentQuestion && currentQuestion.options && currentQuestion.options.length > 0) {
            // Add any collected explanatory items to the question
            if (explanatoryItems.length > 0) {
              currentQuestion.explanatoryItems = [...explanatoryItems];
              // Update question text to include the explanatory items
              let fullText = currentQuestion.text + "\n\n";
              explanatoryItems.forEach(item => {
                fullText += `${item.number} ${item.text}\n`;
              });
              currentQuestion.text = fullText;
            }
            
            questions.push(currentQuestion);
            // Reset explanatory items for next question
            explanatoryItems = [];
          }
          
          // Start a new question
          const questionNumber = questionMatch[1];
          const questionText = questionMatch[2].trim();
          console.log(`Found question ${questionNumber}: ${questionText}`);
          
          currentQuestion = {
            id: nanoid(),
            type: "multiple-choice",
            text: questionText,
            options: [], // Initialize empty array for options
            required: true,
            points: 1,
            explanatoryItems: [] // Initialize empty array for explanatory items
          };
          
          // Start looking for explanatory items after a question
          collectingExplanatoryItems = true;
          continue;
        }
        
        // Check if line contains a numbered item (like "1. Item text")
        const itemMatch = line.match(/^(\d+[\.\)])\s*(.*)/);
        if (itemMatch && collectingExplanatoryItems && currentQuestion) {
          const itemNumber = itemMatch[1];
          const itemText = itemMatch[2].trim();
          console.log(`Found explanatory item ${itemNumber}: ${itemText}`);
          
          // Add to our collection of explanatory items
          explanatoryItems.push({
            number: itemNumber,
            text: itemText
          });
          
          continue;
        }
        
        // Check if line is an option (format like "A) Option text")
        const optionMatch = line.match(/^([A-E][\)])\s*(.*)/);
        if (optionMatch && currentQuestion) {
          const optionLabel = optionMatch[1];
          const optionText = optionMatch[2].trim();
          console.log(`Found option ${optionLabel}: ${optionText}`);
          
          // When we found an option, we're no longer collecting explanatory items
          collectingExplanatoryItems = false;
          
          // Add this option to current question
          if (currentQuestion.options) {
            currentQuestion.options.push({
              id: nanoid(),
              text: optionText,
              isCorrect: false // We'll set the first one as correct by default later
            });
          }
        }
      }
      
      // Don't forget to add the last question
      if (currentQuestion && currentQuestion.options && currentQuestion.options.length > 0) {
        // Add any collected explanatory items to the question
        if (explanatoryItems.length > 0) {
          currentQuestion.explanatoryItems = [...explanatoryItems];
          // Update question text to include the explanatory items
          let fullText = currentQuestion.text + "\n\n";
          explanatoryItems.forEach(item => {
            fullText += `${item.number} ${item.text}\n`;
          });
          currentQuestion.text = fullText;
        }
        
        questions.push(currentQuestion);
      }
      
      // Set first option as correct for each question
      for (const question of questions) {
        if (question.options && question.options.length > 0) {
          question.options[0].isCorrect = true;
        }
      }
      
      // Match images with questions based on position in document
      if (extractedImages && extractedImages.length > 0) {
        for (let i = 0; i < Math.min(questions.length, extractedImages.length); i++) {
          questions[i].imageUrl = `/api/images/${extractedImages[i]}`;
        }
        
        // Add any remaining images as separate questions
        for (let i = questions.length; i < extractedImages.length; i++) {
          questions.push({
            id: nanoid(),
            type: "multiple-choice",
            text: "",
            imageUrl: `/api/images/${extractedImages[i]}`,
            options: [],
            required: true,
            points: 1
          });
        }
      }
      
      // Analyze for potential merges
      const potentialMerges = [];
      for (let i = 0; i < questions.length - 1; i++) {
        // If consecutive questions might be related
        if (questions[i].text && !questions[i+1].text && questions[i+1].imageUrl) {
          potentialMerges.push({
            sourceIndex: i,
            targetIndex: i + 1,
            reason: "Image content that belongs with previous question"
          });
        }
      }
      
      return {
        title,
        questions,
        extractedImages,
        potentialMerges
      };
      
    } catch (error) {
      console.error("Error processing document:", error);
      throw new Error("Failed to process document");
    }
  }
};