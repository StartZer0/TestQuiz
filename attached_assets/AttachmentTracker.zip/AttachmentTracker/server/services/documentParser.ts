import * as mammoth from "mammoth";
import path from "path";
import fs from "fs";

// Define the interface for mammoth.Result to avoid type errors
interface MammothResult {
  value: string;
  messages: Array<any>;
}

// Service for parsing document content
export const documentParser = {
  // Parse DOCX document
  async parseDocument(filePath: string): Promise<MammothResult> {
    try {
      // Ensure the file exists
      if (!fs.existsSync(filePath)) {
        throw new Error(`File does not exist: ${filePath}`);
      }
      
      // Extract text content with mammoth
      const result = await mammoth.extractRawText({ 
        path: filePath 
      });
      
      // Log first 500 characters to help with debugging
      console.log("Document parsing preview:", result.value.substring(0, 500));
      
      // Return the parsed content
      return result;
    } catch (error) {
      console.error("Error parsing document:", error);
      throw new Error("Failed to parse document");
    }
  }
};
