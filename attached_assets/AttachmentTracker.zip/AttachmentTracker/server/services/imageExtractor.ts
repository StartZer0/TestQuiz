import mammoth from "mammoth";
import path from "path";
import fs from "fs";
import { Readable } from "stream";
import { nanoid } from "nanoid";
import sharp from "sharp";

// Directory for extracted images
const IMAGES_DIR = path.join(process.cwd(), "uploads");

// Ensure the directory exists
if (!fs.existsSync(IMAGES_DIR)) {
  fs.mkdirSync(IMAGES_DIR, { recursive: true });
}

// Service for extracting images from documents
export const imageExtractor = {
  // Extract images from DOCX document
  async extractImages(filePath: string): Promise<string[]> {
    const extractedImages: string[] = [];
    
    try {
      // Process document with mammoth for image extraction
      const result = await mammoth.convertToHtml({ path: filePath }, {
        convertImage: mammoth.images.imgElement(async (image) => {
          // Generate a unique filename for the image
          const imageId = nanoid();
          const extension = image.contentType.split('/')[1] || 'png';
          const imageName = `${imageId}.${extension}`;
          const imagePath = path.join(IMAGES_DIR, imageName);
          
          // Write the image to the file system
          const buffer = await image.read();
          
          // Use sharp to process the image if needed
          await sharp(buffer)
            .resize(800, null, { withoutEnlargement: true }) // Resize to max width 800px
            .toFile(imagePath);
          
          // Add to the list of extracted images
          extractedImages.push(imageName);
          
          // Return the image attributes
          return {
            src: `/api/images/${imageName}`
          };
        })
      });
      
      return extractedImages;
    } catch (error) {
      console.error("Error extracting images:", error);
      return []; // Return empty array rather than fail the entire process
    }
  }
};
