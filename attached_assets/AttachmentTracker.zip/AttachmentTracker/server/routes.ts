import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import multer from "multer";
import path from "path";
import fs from "fs";
import { documentController } from "./controllers/documentController";
import { uploadDocumentSchema } from "@shared/schema";

// Configure multer for file uploads
const UPLOADS_DIR = path.join(process.cwd(), "uploads");

// Ensure uploads directory exists
if (!fs.existsSync(UPLOADS_DIR)) {
  fs.mkdirSync(UPLOADS_DIR, { recursive: true });
}

const storage_config = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, UPLOADS_DIR);
  },
  filename: function (req, file, cb) {
    const uniqueSuffix = Date.now() + "-" + Math.round(Math.random() * 1e9);
    cb(null, uniqueSuffix + "-" + file.originalname);
  },
});

const upload = multer({ 
  storage: storage_config,
  limits: { fileSize: 10 * 1024 * 1024 }, // 10MB limit
  fileFilter: (req, file, cb) => {
    // Accept only .docx files initially
    const allowedTypes = [
      'application/vnd.openxmlformats-officedocument.wordprocessingml.document'
    ];
    
    if (allowedTypes.includes(file.mimetype)) {
      cb(null, true);
    } else {
      cb(new Error('Only .docx files are allowed!'));
    }
  },
});

export async function registerRoutes(app: Express): Promise<Server> {
  // Create HTTP server
  const httpServer = createServer(app);

  // API Routes
  // Upload document
  app.post("/api/documents/upload", upload.single('document'), async (req, res) => {
    try {
      if (!req.file) {
        return res.status(400).json({ message: "No file uploaded" });
      }

      const parseData = {
        fileName: req.file.filename,
        userId: req.body.userId ? parseInt(req.body.userId) : undefined,
      };

      // Validate upload data
      const validatedData = uploadDocumentSchema.parse(parseData);
      
      // Process document
      const result = await documentController.processDocument(validatedData);
      
      return res.status(200).json(result);
    } catch (error: any) {
      console.error("Error uploading document:", error);
      return res.status(500).json({ 
        message: error.message || "Failed to process document" 
      });
    }
  });

  // Get extracted image
  app.get("/api/images/:imageName", (req, res) => {
    try {
      const imagePath = path.join(UPLOADS_DIR, req.params.imageName);
      
      if (!fs.existsSync(imagePath)) {
        return res.status(404).json({ message: "Image not found" });
      }
      
      res.sendFile(imagePath);
    } catch (error: any) {
      console.error("Error fetching image:", error);
      return res.status(500).json({ 
        message: error.message || "Failed to fetch image" 
      });
    }
  });

  // Save form
  app.post("/api/forms", async (req, res) => {
    try {
      const formData = req.body;
      const result = await storage.createForm(formData);
      return res.status(201).json(result);
    } catch (error: any) {
      console.error("Error saving form:", error);
      return res.status(500).json({ 
        message: error.message || "Failed to save form" 
      });
    }
  });

  // Get form
  app.get("/api/forms/:id", async (req, res) => {
    try {
      const formId = parseInt(req.params.id);
      const form = await storage.getForm(formId);
      
      if (!form) {
        return res.status(404).json({ message: "Form not found" });
      }
      
      return res.status(200).json(form);
    } catch (error: any) {
      console.error("Error fetching form:", error);
      return res.status(500).json({ 
        message: error.message || "Failed to fetch form" 
      });
    }
  });

  return httpServer;
}
